// FILE: script.js (PERSIST CART + AUTO CHECKOUT AFTER SETTINGS)

const cartBtn = document.querySelector('#cart-btn');
const cartContainer = document.querySelector('#cart-container');
const cartItemsList = document.querySelector('#cart-items');
const cartTotal = document.querySelector('#cart-total');
const checkoutBtn = document.querySelector('#checkout-btn');

const accountBtn = document.querySelector('#account-btn');
const accountDropdown = document.querySelector('#account-dropdown');
const logoutBtn = document.querySelector('#logout-btn');

const helloText = document.querySelector('#hello-text');
const emailText = document.querySelector('#email-text');

const accountSettingsBtn = document.querySelector('#account-settings-btn');
const addressBtn = document.querySelector('#address-btn');
const numberBtn = document.querySelector('#number-btn');

// ===== CART PERSISTENCE =====
function saveCart() {
  localStorage.setItem("cartItems", JSON.stringify(cart));
}
function loadCart() {
  try {
    const saved = JSON.parse(localStorage.getItem("cartItems") || "[]");
    if (Array.isArray(saved)) cart = saved;
  } catch (e) {}
}

// ===== CART DATA =====
let cart = [];
loadCart();

// ===== HELPERS =====
function isLoggedIn() {
  return localStorage.getItem("loggedIn") === "true";
}
function getUserId() {
  return localStorage.getItem("userId");
}
function getUserName() {
  return localStorage.getItem("userName") || "User";
}
function getUserEmail() {
  return localStorage.getItem("userEmail") || "";
}
function closeAccountDropdown() {
  if (accountDropdown) accountDropdown.classList.remove("active");
}
function closeCart() {
  if (cartContainer) cartContainer.classList.remove("active");
}

// ===== GET USER PROFILE FROM DB =====
async function fetchUserProfile() {
  const userId = getUserId();
  if (!userId) return null;

  try {
    const res = await fetch("api/users/profile.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: userId })
    });

    const data = await res.json();
    if (!data.success) return null;
    return data.user;
  } catch (e) {
    return null;
  }
}

// ===== ACCOUNT BUTTON =====
if (accountBtn) {
  if (isLoggedIn()) {
    accountBtn.style.color = "#e94b8b";
    accountBtn.title = "Account";
  } else {
    accountBtn.title = "Login";
  }

  accountBtn.addEventListener("click", (e) => {
    e.stopPropagation();

    if (!isLoggedIn()) {
      window.location.href = "account.html";
      return;
    }

    if (helloText) helloText.textContent = `Hello, ${getUserName()}`;
    if (emailText) emailText.textContent = getUserEmail();

    if (accountDropdown) accountDropdown.classList.toggle("active");
  });
}

// ===== LOGOUT =====
if (logoutBtn) {
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("loggedIn");
    localStorage.removeItem("userId");
    localStorage.removeItem("userName");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("userNumber");
    localStorage.removeItem("userAddress");

    alert("Logged out successfully!");
    closeAccountDropdown();
    location.reload();
  });
}

// ===== DROPDOWN LINKS =====
if (accountSettingsBtn)
  accountSettingsBtn.addEventListener("click", () => window.location.href = "account_settings.html");
if (addressBtn)
  addressBtn.addEventListener("click", () => window.location.href = "account_settings.html#address");
if (numberBtn)
  numberBtn.addEventListener("click", () => window.location.href = "account_settings.html#number");

// ===== CLOSE WHEN CLICK OUTSIDE =====
document.addEventListener("click", (e) => {
  const accountWrap = document.querySelector(".account-wrapper");
  if (accountWrap && accountDropdown && !accountWrap.contains(e.target)) closeAccountDropdown();

  const cartWrapClick = cartContainer && cartContainer.contains(e.target);
  const cartBtnClick = cartBtn && cartBtn.contains(e.target);
  if (cartContainer && !cartWrapClick && !cartBtnClick) closeCart();
});

// ===== CART TOGGLE =====
if (cartBtn && cartContainer) {
  cartBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    cartContainer.classList.toggle("active");
  });
}

// ===== ADD TO CART =====
document.querySelectorAll('.add-to-cart').forEach((btn) => {
  btn.addEventListener('click', () => {
    const box = btn.closest('.menu-box');
    if (!box) return;

    const name = box.dataset.name || "Item";
    const price = parseFloat(box.dataset.price || "0");

    cart.push({ name, price });
    saveCart();
    updateCart();

    // keep cart open
    if (cartContainer) cartContainer.classList.add("active");
  });
});

// ===== UPDATE CART UI =====
function updateCart() {
  if (!cartItemsList || !cartTotal) return;

  cartItemsList.innerHTML = '';
  let total = 0;

  cart.forEach((item, index) => {
    total += item.price;

    const li = document.createElement('li');
    li.style.display = "flex";
    li.style.justifyContent = "space-between";

    const text = document.createElement("span");
    text.textContent = `${item.name} - ₱${item.price}`;

    const removeBtn = document.createElement("button");
    removeBtn.textContent = "Remove";
    removeBtn.onclick = () => {
      cart.splice(index, 1);
      saveCart();
      updateCart();
    };

    li.appendChild(text);
    li.appendChild(removeBtn);
    cartItemsList.appendChild(li);
  });

  cartTotal.textContent = `Total: ₱${total.toFixed(2)}`;
}

// Initial render
updateCart();

// ===== DO THE ACTUAL ORDER SUBMIT =====
async function submitOrderWithProfile(profile) {
  const orderDetails = cart.map(item => `${item.name} - ₱${item.price}`).join(", ");
  const total = cart.reduce((sum, item) => sum + item.price, 0).toFixed(2);

  const res = await fetch("api/orders/create.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: profile.full_name,
      address: profile.address,
      phone: profile.phone,
      order_details: orderDetails,
      total_price: total
    })
  });

  return res.json();
}

// ===== CHECKOUT =====
if (checkoutBtn) {
  checkoutBtn.addEventListener('click', async () => {
    if (!isLoggedIn()) {
      alert("Please log in first before checking out.");
      window.location.href = "account.html";
      return;
    }

    if (cart.length === 0) {
      alert("Your cart is empty!");
      return;
    }

    const profile = await fetchUserProfile();

    if (!profile) {
      alert("Could not load your account info.");
      return;
    }

    // Missing address/phone? Save pending checkout and go settings
    if (!profile.address || !profile.phone) {
      localStorage.setItem("pendingCheckout", "true");
      alert("Please complete your Address and Phone Number first.");
      window.location.href = "account_settings.html";
      return;
    }

    try {
      const data = await submitOrderWithProfile(profile);

      if (!data.success) {
        alert("Failed: " + (data.message || "Unknown error"));
        return;
      }

      alert("Thank you for ordering with KainLokal!");

      cart = [];
      saveCart();
      updateCart();
      closeCart();

      localStorage.removeItem("pendingCheckout");
    } catch (err) {
      alert("Server error. Make sure Apache and MySQL are running.");
    }
  });
}

// ===== AUTO CHECKOUT AFTER SETTINGS SAVE =====
(async function autoCheckoutAfterSettings() {
  // if we came back with #autoCheckout and pendingCheckout is true
  if (window.location.hash === "#autoCheckout" && localStorage.getItem("pendingCheckout") === "true") {
    // open cart so you can see it
    if (cartContainer) cartContainer.classList.add("active");

    if (!isLoggedIn()) return;

    if (cart.length === 0) {
      localStorage.removeItem("pendingCheckout");
      return;
    }

    const profile = await fetchUserProfile();
    if (!profile || !profile.address || !profile.phone) return;

    try {
      const data = await submitOrderWithProfile(profile);

      if (!data.success) return;

      alert("Thank you for ordering with KainLokal!");

      cart = [];
      saveCart();
      updateCart();
      closeCart();

      localStorage.removeItem("pendingCheckout");
      // clean URL hash
      history.replaceState(null, "", "index.html");
    } catch (e) {}
  }
})();
