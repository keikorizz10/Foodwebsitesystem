// FILE: account_settings.js (SAVES TO MYSQL + RETURNS TO CHECKOUT)

if (localStorage.getItem("loggedIn") !== "true") {
  window.location.href = "account.html";
}

const userId = localStorage.getItem("userId");

const setName = document.getElementById("set-name");
const setEmail = document.getElementById("set-email");
const setAddress = document.getElementById("set-address");
const setNumber = document.getElementById("set-number");

const msgBasic = document.getElementById("msg-basic");
const msgAddress = document.getElementById("msg-address");
const msgNumber = document.getElementById("msg-number");

function setMsg(el, text, type) {
  el.textContent = text;
  el.className = "msg " + (type || "");
}

async function loadProfile() {
  try {
    const res = await fetch("api/users/profile.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: userId })
    });

    const data = await res.json();
    if (!data.success) return;

    // Fill inputs from DB
    setName.value = data.user.full_name || "";
    setEmail.value = data.user.email || "";
    setAddress.value = data.user.address || "";
    setNumber.value = data.user.phone || "";

    // Sync localStorage too (for greeting)
    localStorage.setItem("userName", data.user.full_name || "");
    localStorage.setItem("userEmail", data.user.email || "");
    localStorage.setItem("userAddress", data.user.address || "");
    localStorage.setItem("userNumber", data.user.phone || "");
  } catch (e) {}
}

async function updateProfile(payload) {
  const res = await fetch("api/users/update_profile.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user_id: userId, ...payload })
  });
  return res.json();
}

function returnToCheckoutIfPending() {
  // If user came here because checkout needs info, auto-go back and finish
  if (localStorage.getItem("pendingCheckout") === "true") {
    // Go back to index and auto-submit
    window.location.href = "index.html#autoCheckout";
  }
}

// Load values from DB on page open
loadProfile();

// Save basic info
document.getElementById("save-basic").onclick = async () => {
  const name = setName.value.trim();
  const email = setEmail.value.trim();

  if (!name) return setMsg(msgBasic, "Name is required.", "err");
  if (!email.includes("@")) return setMsg(msgBasic, "Enter a valid email.", "err");

  try {
    const data = await updateProfile({ full_name: name, email });
    if (!data.success) return setMsg(msgBasic, data.message || "Save failed.", "err");

    localStorage.setItem("userName", name);
    localStorage.setItem("userEmail", email);

    setMsg(msgBasic, "Saved!", "ok");
    returnToCheckoutIfPending();
  } catch (e) {
    setMsg(msgBasic, "Server error.", "err");
  }
};

// Save address
document.getElementById("save-address").onclick = async () => {
  const address = setAddress.value.trim();
  if (!address) return setMsg(msgAddress, "Address is required.", "err");

  try {
    const data = await updateProfile({ address });
    if (!data.success) return setMsg(msgAddress, data.message || "Save failed.", "err");

    localStorage.setItem("userAddress", address);

    setMsg(msgAddress, "Saved!", "ok");
    returnToCheckoutIfPending();
  } catch (e) {
    setMsg(msgAddress, "Server error.", "err");
  }
};

// Save number
document.getElementById("save-number").onclick = async () => {
  const phone = setNumber.value.trim();
  if (!phone) return setMsg(msgNumber, "Number is required.", "err");

  try {
    const data = await updateProfile({ phone });
    if (!data.success) return setMsg(msgNumber, data.message || "Save failed.", "err");

    localStorage.setItem("userNumber", phone);

    setMsg(msgNumber, "Saved!", "ok");
    returnToCheckoutIfPending();
  } catch (e) {
    setMsg(msgNumber, "Server error.", "err");
  }
};
