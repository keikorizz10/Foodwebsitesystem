// FILE: C:\xampp\htdocs\kainlokal\account.js
// UPDATED: If NOT registered -> switch to signup panel automatically

const loginPanel = document.getElementById("login-panel");
const signupPanel = document.getElementById("signup-panel");

const toSignup = document.getElementById("to-signup");
const toLogin = document.getElementById("to-login");

const loginForm = document.getElementById("login-form");
const signupForm = document.getElementById("signup-form");

const loginMsg = document.getElementById("login-msg");
const signupMsg = document.getElementById("signup-msg");

const forgotBtn = document.getElementById("forgot-btn");

function show(panel) {
  if (panel === "login") {
    signupPanel.classList.add("hidden");
    loginPanel.classList.remove("hidden");
    clearMsgs();
  } else {
    loginPanel.classList.add("hidden");
    signupPanel.classList.remove("hidden");
    clearMsgs();
  }
}

function setMsg(el, text, type) {
  el.textContent = text;
  el.classList.remove("ok", "err");
  if (type) el.classList.add(type);
}

function clearMsgs() {
  setMsg(loginMsg, "", null);
  setMsg(signupMsg, "", null);
}

if (toSignup) toSignup.addEventListener("click", () => show("signup"));
if (toLogin) toLogin.addEventListener("click", () => show("login"));

if (forgotBtn) {
  forgotBtn.addEventListener("click", () => {
    alert("Forgot password is not connected yet.");
  });
}

// SIGNUP -> MySQL
if (signupForm) {
  signupForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearMsgs();

    const full_name = document.getElementById("signup-name").value.trim();
    const email = document.getElementById("signup-email").value.trim();
    const p1 = document.getElementById("signup-pass").value;
    const p2 = document.getElementById("signup-pass2").value;

    if (!full_name || !email || !p1 || !p2) {
      setMsg(signupMsg, "Please complete all fields.", "err");
      return;
    }
    if (!email.includes("@")) {
      setMsg(signupMsg, "Please enter a valid email.", "err");
      return;
    }
    if (p1.length < 6) {
      setMsg(signupMsg, "Password must be at least 6 characters.", "err");
      return;
    }
    if (p1 !== p2) {
      setMsg(signupMsg, "Passwords do not match.", "err");
      return;
    }

    try {
      const res = await fetch("api/users/signup.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ full_name, email, password: p1 })
      });

      const data = await res.json();

      if (!data.success) {
        setMsg(signupMsg, data.message || "Signup failed.", "err");
        return;
      }

      setMsg(signupMsg, "Signup successful! You can now log in.", "ok");
      setTimeout(() => show("login"), 800);

    } catch (err) {
      setMsg(signupMsg, "Server error. Check Apache/MySQL.", "err");
    }
  });
}

// LOGIN -> MySQL
if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearMsgs();

    const email = document.getElementById("login-email").value.trim();
    const password = document.getElementById("login-pass").value;

    if (!email || !password) {
      setMsg(loginMsg, "Please fill in email and password.", "err");
      return;
    }

    try {
      const res = await fetch("api/users/login.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });

      const data = await res.json();

      if (!data.success) {
        // If not registered -> show signup panel automatically
        if (data.code === "NOT_REGISTERED") {
          setMsg(loginMsg, data.message || "Account not found.", "err");
          setTimeout(() => show("signup"), 900);
          return;
        }

        setMsg(loginMsg, data.message || "Login failed.", "err");
        return;
      }

      // Save session (front-end session demo)
      localStorage.setItem("loggedIn", "true");
      localStorage.setItem("userId", data.user.id);
      localStorage.setItem("userName", data.user.full_name);
      localStorage.setItem("userEmail", data.user.email);

      if (data.user.phone) localStorage.setItem("userNumber", data.user.phone);
      if (data.user.address) localStorage.setItem("userAddress", data.user.address);

      setMsg(loginMsg, "Login successful! Redirecting...", "ok");

      setTimeout(() => {
        window.location.href = "index.html";
      }, 700);

    } catch (err) {
      setMsg(loginMsg, "Server error. Check Apache/MySQL.", "err");
    }
  });
}
