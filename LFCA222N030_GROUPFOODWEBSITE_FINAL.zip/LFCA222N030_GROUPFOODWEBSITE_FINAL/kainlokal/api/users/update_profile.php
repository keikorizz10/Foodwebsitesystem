<?php
// FILE: api/users/update_profile.php
header("Content-Type: application/json");

require_once __DIR__ . "/../config/database.php";

$database = new Database();
$db = $database->connect();

$data = json_decode(file_get_contents("php://input"));

if (empty($data->user_id)) {
  echo json_encode(["success" => false, "message" => "Missing user_id"]);
  exit;
}

$user_id = (int)$data->user_id;
$full_name = isset($data->full_name) ? trim($data->full_name) : null;
$email = isset($data->email) ? trim($data->email) : null;
$phone = isset($data->phone) ? trim($data->phone) : null;
$address = isset($data->address) ? trim($data->address) : null;

try {
  // Build dynamic update query
  $fields = [];
  $values = [];

  if ($full_name !== null && $full_name !== "") { $fields[] = "full_name = ?"; $values[] = $full_name; }
  if ($email !== null && $email !== "") { $fields[] = "email = ?"; $values[] = $email; }
  if ($phone !== null) { $fields[] = "phone = ?"; $values[] = $phone; }
  if ($address !== null) { $fields[] = "address = ?"; $values[] = $address; }

  if (count($fields) === 0) {
    echo json_encode(["success" => false, "message" => "Nothing to update"]);
    exit;
  }

  $values[] = $user_id;

  $sql = "UPDATE users SET " . implode(", ", $fields) . " WHERE id = ?";
  $stmt = $db->prepare($sql);
  $stmt->execute($values);

  echo json_encode(["success" => true, "message" => "Profile updated"]);
} catch (Exception $e) {
  echo json_encode(["success" => false, "message" => "Database error"]);
}
