<?php
header("Content-Type: application/json");

require_once __DIR__ . "/../config/database.php";

$database = new Database();
$db = $database->connect();

$data = json_decode(file_get_contents("php://input"));

if (
    empty($data->full_name) ||
    empty($data->email) ||
    empty($data->password)
) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required fields"
    ]);
    exit;
}

$full_name = $data->full_name;
$email = $data->email;
$password = password_hash($data->password, PASSWORD_DEFAULT);

try {

    // Check if email exists
    $check = $db->prepare("SELECT id FROM users WHERE email = ?");
    $check->execute([$email]);

    if ($check->rowCount() > 0) {
        echo json_encode([
            "success" => false,
            "message" => "Email already exists"
        ]);
        exit;
    }

    // Insert user
    $query = "INSERT INTO users (full_name, email, password_hash)
              VALUES (?, ?, ?)";

    $stmt = $db->prepare($query);

    $stmt->execute([
        $full_name,
        $email,
        $password
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Signup successful"
    ]);

} catch (Exception $e) {

    echo json_encode([
        "success" => false,
        "message" => "Database error"
    ]);
}
?>
