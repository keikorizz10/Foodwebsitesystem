<?php
// FILE: C:\xampp\htdocs\kainlokal\api\users\login.php
header("Content-Type: application/json");

require_once __DIR__ . "/../config/database.php";

$database = new Database();
$db = $database->connect();

$data = json_decode(file_get_contents("php://input"));

if (empty($data->email) || empty($data->password)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing email or password",
        "code" => "MISSING_FIELDS"
    ]);
    exit;
}

$email = $data->email;
$password = $data->password;

try {
    $stmt = $db->prepare("SELECT id, full_name, email, password_hash, phone, address FROM users WHERE email = ?");
    $stmt->execute([$email]);

    // If email not registered
    if ($stmt->rowCount() === 0) {
        echo json_encode([
            "success" => false,
            "message" => "Account not found. Please sign up first.",
            "code" => "NOT_REGISTERED"
        ]);
        exit;
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // If password wrong
    if (!password_verify($password, $user["password_hash"])) {
        echo json_encode([
            "success" => false,
            "message" => "Wrong password.",
            "code" => "WRONG_PASSWORD"
        ]);
        exit;
    }

    echo json_encode([
        "success" => true,
        "message" => "Login successful",
        "user" => [
            "id" => $user["id"],
            "full_name" => $user["full_name"],
            "email" => $user["email"],
            "phone" => $user["phone"],
            "address" => $user["address"]
        ]
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Database error",
        "code" => "DB_ERROR"
    ]);
}
?>
