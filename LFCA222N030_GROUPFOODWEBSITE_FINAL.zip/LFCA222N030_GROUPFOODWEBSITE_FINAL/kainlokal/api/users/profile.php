<?php
// FILE: api/users/profile.php
header("Content-Type: application/json");

require_once __DIR__ . "/../config/database.php";

$database = new Database();
$db = $database->connect();

$data = json_decode(file_get_contents("php://input"));

if (empty($data->user_id)) {
  echo json_encode([
    "success" => false,
    "message" => "Missing user_id",
    "code" => "MISSING_USER_ID"
  ]);
  exit;
}

$user_id = (int)$data->user_id;

try {
  $stmt = $db->prepare("SELECT id, full_name, email, phone, address FROM users WHERE id = ?");
  $stmt->execute([$user_id]);

  if ($stmt->rowCount() === 0) {
    echo json_encode([
      "success" => false,
      "message" => "User not found",
      "code" => "USER_NOT_FOUND"
    ]);
    exit;
  }

  $user = $stmt->fetch(PDO::FETCH_ASSOC);

  echo json_encode([
    "success" => true,
    "user" => [
      "id" => $user["id"],
      "full_name" => $user["full_name"],
      "email" => $user["email"],
      "phone" => $user["phone"],
      "address" => $user["address"]
    ]
  ]);

} catch (Exception $e) {
  echo json_encode([
    "success" => false,
    "message" => "Database error",
    "code" => "DB_ERROR"
  ]);
}
