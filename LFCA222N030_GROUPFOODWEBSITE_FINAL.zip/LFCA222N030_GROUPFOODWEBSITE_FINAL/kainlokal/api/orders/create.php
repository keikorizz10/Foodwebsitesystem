<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once __DIR__ . "/../config/database.php";

$database = new Database();
$db = $database->connect();

$data = json_decode(file_get_contents("php://input"));

if (
    empty($data->name) ||
    empty($data->address) ||
    empty($data->phone) ||
    empty($data->order_details) ||
    empty($data->total_price)
) {
    echo json_encode(["success" => false, "message" => "Missing fields"]);
    exit;
}

try {
    // Insert customer
    $query1 = "INSERT INTO customers (name, address, phone) VALUES (?, ?, ?)";
    $stmt1 = $db->prepare($query1);
    $stmt1->execute([
        $data->name,
        $data->address,
        $data->phone
    ]);

    $customer_id = $db->lastInsertId();

    // Insert order
    $query2 = "INSERT INTO orders (customer_id, order_details, total_price)
               VALUES (?, ?, ?)";
    $stmt2 = $db->prepare($query2);
    $stmt2->execute([
        $customer_id,
        $data->order_details,
        $data->total_price
    ]);

    echo json_encode(["success" => true, "message" => "Order saved"]);

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Database error"]);
}
